import { createServer } from "node:http";

const token = process.env.TELEGRAM_BOT_TOKEN;
const miniAppUrl = process.env.MINI_APP_URL;
const animationUrl = "https://videovssylku.ru/v/18087548094990.4uAzb";
const apiUrl = token ? `https://api.telegram.org/bot${token}` : null;
const port = Number(process.env.PORT ?? 10000);

if (!token || !miniAppUrl) {
  console.error("Set TELEGRAM_BOT_TOKEN and MINI_APP_URL before starting the bot.");
  process.exit(1);
}

const isLocalUrl = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(miniAppUrl);
if (!/^https:\/\//i.test(miniAppUrl) && !isLocalUrl) {
  console.error("MINI_APP_URL must be an HTTPS URL, except for localhost testing.");
  process.exit(1);
}
if (isLocalUrl) {
  console.warn("Localhost Mini App URL is only useful on the same device; Telegram on a phone cannot reach your computer's localhost.");
}

const healthServer = createServer((request, response) => {
  if (request.url === "/health" || request.url === "/") {
    response.writeHead(200, { "content-type": "text/plain; charset=utf-8" });
    response.end("NotCoin bot is running");
    return;
  }
  response.writeHead(404);
  response.end("Not found");
});

healthServer.listen(port, "0.0.0.0", () => {
  console.log(`Bot health server listening on port ${port}`);
});

async function telegram(method, payload) {
  const response = await fetch(`${apiUrl}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
  const result = await response.json();
  if (!result.ok) {
    throw new Error(`Telegram ${method} failed: ${result.description ?? "unknown error"}`);
  }
  return result.result;
}

async function sendWelcome(chatId) {
  const caption = [
    "Добро пожаловать в NotCoin",
    "",
    "Открывайте коллекции, находите редкие Telegram-подарки и управляйте своей коллекцией в одном месте.",
    "",
    "Нажмите кнопку ниже, чтобы открыть маркетплейс прямо внутри Telegram.",
  ].join("\n");
  const replyMarkup = {
    inline_keyboard: [[{ text: "Открыть NotCoin", web_app: { url: miniAppUrl } }]],
  };
  try {
    await telegram("sendAnimation", {
      chat_id: chatId,
      animation: animationUrl,
      caption,
      reply_markup: replyMarkup,
    });
  } catch (error) {
    console.error(`GIF could not be sent, using text fallback: ${error instanceof Error ? error.message : error}`);
    await telegram("sendMessage", { chat_id: chatId, text: caption, reply_markup: replyMarkup });
  }
}

let offset = 0;
let polling = true;

async function poll() {
  while (polling) {
    try {
      const updates = await telegram("getUpdates", {
        offset,
        timeout: 25,
        allowed_updates: ["message"],
      });
      for (const update of updates) {
        offset = update.update_id + 1;
        const message = update.message;
        if (!message?.chat?.id) continue;
        if (message.text) {
          await sendWelcome(message.chat.id);
        }
      }
    } catch (error) {
      console.error(error instanceof Error ? error.message : error);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

async function shutdown() {
  polling = false;
  healthServer.close();
  try {
    await telegram("deleteWebhook", { drop_pending_updates: false });
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
  }
  process.exit(0);
}

process.once("SIGINT", shutdown);
process.once("SIGTERM", shutdown);

await telegram("deleteWebhook", { drop_pending_updates: false });
console.log(`NotCoin bot is running. Mini App: ${miniAppUrl}`);
await poll();
